'use client'

import { useSession, signOut } from 'next-auth/react'
import Link from 'next/link'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Briefcase, User, LogOut, Settings } from 'lucide-react'

export function Navbar() {
  const { data: session } = useSession()

  if (!session) return null

  return (
    <nav className="bg-white shadow-sm border-b">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          <div className="flex items-center">
            <Link href="/dashboard" className="flex items-center">
              <Briefcase className="h-8 w-8 text-blue-600 mr-2" />
              <span className="text-xl font-bold text-gray-900">SkillSync</span>
            </Link>
          </div>

          <div className="flex items-center space-x-4">
            {session.user.role === 'STUDENT' && (
              <>
                <Link href="/jobs">
                  <Button variant="ghost">Jobs</Button>
                </Link>
                <Link href="/applications">
                  <Button variant="ghost">Applications</Button>
                </Link>
              </>
            )}

            {session.user.role === 'EMPLOYER' && (
              <>
                <Link href="/employer/jobs">
                  <Button variant="ghost">My Jobs</Button>
                </Link>
                <Link href="/employer/jobs/new">
                  <Button variant="ghost">Post Job</Button>
                </Link>
              </>
            )}

            <Link href="/profile">
              <Button variant="ghost" size="sm">
                <User className="h-4 w-4 mr-2" />
                Profile
              </Button>
            </Link>

            <Link href="/settings">
              <Button variant="ghost" size="sm">
                <Settings className="h-4 w-4" />
              </Button>
            </Link>

            <Badge variant="outline" className="capitalize">
              {session.user.role.toLowerCase()}
            </Badge>

            <Button
              variant="ghost"
              size="sm"
              onClick={() => signOut({ callbackUrl: '/' })}
            >
              <LogOut className="h-4 w-4 mr-2" />
              Sign Out
            </Button>
          </div>
        </div>
      </div>
    </nav>
  )
}
