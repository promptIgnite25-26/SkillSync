import { UserRole, JobType, JobMode, ApplicationStatus } from '@prisma/client'

export type { UserRole, JobType, JobMode, ApplicationStatus }

export interface User {
  id: string
  email: string
  role: UserRole
}

declare module 'next-auth' {
  interface Session {
    user: User
  }
}

declare module 'next-auth/jwt' {
  interface JWT {
    role: string
  }
}
