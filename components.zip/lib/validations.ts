import { z } from 'zod'

export const registerSchema = z.object({
  email: z.string().email('Invalid email address'),
  password: z.string().min(6, 'Password must be at least 6 characters'),
  role: z.enum(['STUDENT', 'EMPLOYER']),
})

export const loginSchema = z.object({
  email: z.string().email('Invalid email address'),
  password: z.string().min(1, 'Password is required'),
})

export const studentProfileSchema = z.object({
  fullName: z.string().min(1, 'Full name is required'),
  college: z.string().min(1, 'College is required'),
  degree: z.string().min(1, 'Degree is required'),
  branch: z.string().min(1, 'Branch is required'),
  year: z.string().min(1, 'Year is required'),
  cgpa: z.number().min(0).max(10).optional(),
  skills: z.array(z.string()).min(1, 'At least one skill is required'),
  location: z.string().optional(),
  portfolioUrl: z.string().url().optional().or(z.literal('')),
  about: z.string().optional(),
})

export const employerProfileSchema = z.object({
  companyName: z.string().min(1, 'Company name is required'),
  website: z.string().url().optional().or(z.literal('')),
  location: z.string().optional(),
  about: z.string().optional(),
  contactEmail: z.string().email().optional().or(z.literal('')),
  contactPhone: z.string().optional(),
})

export const jobSchema = z.object({
  title: z.string().min(1, 'Job title is required'),
  description: z.string().min(1, 'Job description is required'),
  type: z.enum(['INTERNSHIP', 'FULL_TIME', 'PART_TIME']),
  mode: z.enum(['ONSITE', 'REMOTE', 'HYBRID']),
  location: z.string().min(1, 'Location is required'),
  compensation: z.string().optional(),
  skills: z.array(z.string()).min(1, 'At least one skill is required'),
  minCGPA: z.number().min(0).max(10).optional(),
  yearAllowed: z.array(z.string()).min(1, 'At least one year is required'),
  applyBy: z.string().min(1, 'Apply by date is required'),
})

export const applicationSchema = z.object({
  jobId: z.string().min(1, 'Job ID is required'),
  coverLetter: z.string().optional(),
})

export const updateApplicationSchema = z.object({
  status: z.enum(['APPLIED', 'SHORTLISTED', 'REJECTED', 'HIRED']),
  notes: z.string().optional(),
})

export const jobFiltersSchema = z.object({
  q: z.string().optional(),
  type: z.enum(['INTERNSHIP', 'FULL_TIME', 'PART_TIME']).optional(),
  mode: z.enum(['ONSITE', 'REMOTE', 'HYBRID']).optional(),
  location: z.string().optional(),
  skills: z.array(z.string()).optional(),
  minCGPA: z.number().optional(),
  year: z.string().optional(),
})
